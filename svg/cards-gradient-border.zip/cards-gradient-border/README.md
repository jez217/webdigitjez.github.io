# Cards (gradient border)

A Pen created on CodePen.io. Original URL: [https://codepen.io/dtab428/pen/GRPVQXR](https://codepen.io/dtab428/pen/GRPVQXR).

